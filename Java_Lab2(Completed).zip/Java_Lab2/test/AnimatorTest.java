import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import raycast.animator.AbstractAnimator;
import raycast.animator.TextAnimator;

class AnimatorTest {

	private AbstractAnimator a;

	@BeforeEach
	void setUp() {

		a = new TextAnimator();
	}

	@AfterEach
	void tearDown() {

		a = null;
	}

	@Test
	void abbcTest() {

		boolean doesIntersect = a.getIntersection(100, 100, 200, 100, 200, 100, 200, 200);

		double[] result = a.intersect();


		assertEquals(result[0], 200, 0.0001);
		assertEquals(result[1], 100, 0.0001);
		assertEquals(result[2], 1, 0.0001);

		assertTrue(doesIntersect);
	}

	@Test
	void abadTest() {

		boolean doesIntersect = a.getIntersection(100, 100, 200, 100, 100, 100, 100, 200);

		double[] result = a.intersect();

		assertTrue(doesIntersect);

		assertEquals(result[0], 100, 0.0001);
		assertEquals(result[1], 100, 0.0001);
		assertEquals(result[2], 0, 0.0001);

	}

	@Test
	void abfhTest() {

		boolean doesIntersect = a.getIntersection(100, 100, 200, 100, 150, 100, 150, 200);

		double[] result = a.intersect();

		assertTrue(doesIntersect);

		assertEquals(result[0], 150, 0.0001);
		assertEquals(result[1], 100, 0.0001);
		assertEquals(result[2], 0.5, 0.0001);

	}

	@Test
	void baadTest() {

		boolean doesIntersect = a.getIntersection(100, 100, 200, 100, 200, 100, 200, 200);

		double[] result = a.intersect();

		assertTrue(doesIntersect);

		assertEquals(result[0], 200, 0.0001);
		assertEquals(result[1], 100, 0.0001);
		assertEquals(result[2], 1, 0.0001);

	}

	@Test
	void bafhtest() {

		boolean doesIntersect = a.getIntersection(200, 100, 100, 100, 150, 100, 150, 200);

		double[] result = a.intersect();

		assertTrue(doesIntersect);

		assertEquals(result[0], 150, 0.0001);
		assertEquals(result[1], 100, 0.0001);
		assertEquals(result[2], 0.5, 0.0001);

	}

	@Test
	void babcTest() {

		boolean doesIntersect = a.getIntersection(200, 100, 100, 100, 200, 100, 200, 200);

		double[] result = a.intersect();

		assertTrue(doesIntersect);

		assertEquals(result[0], 200, 0.0001);
		assertEquals(result[1], 100, 0.0001);
		assertEquals(result[2], 0, 0.0001);

	}

	@Test
	void abidTest() {

		boolean doesIntersect = a.getIntersection(100, 100, 200, 100, 100, 150, 100, 200);

		double[] result = a.intersect();

		assertFalse(doesIntersect);

	}

	@Test
	void abehTest() {

		boolean doesIntersect = a.getIntersection(100, 100, 200, 100, 150, 1500, 1500, 200);

		double[] result = a.intersect();

		assertFalse(doesIntersect);

	}

	@Test
	void abgcTest() {

		boolean doesIntersect = a.getIntersection(100, 100, 200, 100, 200, 150, 200, 200);

		double[] result = a.intersect();

		assertFalse(doesIntersect);

	}

	@Test
	void abigTest() {

		boolean doesIntersect = a.getIntersection(100, 100, 200, 100, 100, 150, 200, 150);

		double[] result = a.intersect();

		assertFalse(doesIntersect);

	}

	@Test
	void baidTest() {

		boolean doesIntersect = a.getIntersection(200, 100, 100, 100, 100, 150, 100, 200);

		double[] result = a.intersect();

		assertFalse(doesIntersect);

	}

	@Test
	void baehTest() {

		boolean doesIntersect = a.getIntersection(200, 100, 100, 100, 150, 150, 150, 200);

		double[] result = a.intersect();

		assertFalse(doesIntersect);

	}

	@Test
	void bagcTest() {

		boolean doesIntersect = a.getIntersection(200, 100, 100, 100, 200, 150, 200, 200);

		double[] result = a.intersect();

		assertFalse(doesIntersect);

	}

	@Test
	void baigTest() {

		boolean doesIntersect = a.getIntersection(200, 100, 100, 100, 100, 150, 200, 150);

		double[] result = a.intersect();

		assertFalse(doesIntersect);

	}

	@Test
	void afadTest() {

		boolean doesIntersect = a.getIntersection(100, 100, 150, 100, 100, 100, 100, 200);

		double[] result = a.intersect();

		assertTrue(doesIntersect);

		assertEquals(result[0], 100, 0.0001);
		assertEquals(result[1], 100, 0.0001);
		assertEquals(result[2], 0, 0.0001);

	}

	@Test
	void affhTest() {

		boolean doesIntersect = a.getIntersection(100, 100, 150, 100, 150, 100, 150, 200);

		double[] result = a.intersect();

		assertTrue(doesIntersect);

		assertEquals(result[0], 150, 0.0001);
		assertEquals(result[1], 100, 0.0001);
		assertEquals(result[2], 1, 0.0001);

	}

	@Test
	void afbcTest() {

		boolean doesIntersect = a.getIntersection(100, 100, 150, 100, 200, 100, 200, 200);

		double[] result = a.intersect();

		assertTrue(doesIntersect);

		assertEquals(result[0], 200, 0.0001);
		assertEquals(result[1], 100, 0.0001);
		assertEquals(result[2], 2, 0.0001);

	}

	@Test
	void faadTest() {

		boolean doesIntersect = a.getIntersection(150, 100, 100, 100, 100, 100, 100, 200);

		double[] result = a.intersect();

		assertTrue(doesIntersect);

		assertEquals(result[0], 100, 0.0001);
		assertEquals(result[1], 100, 0.0001);
		assertEquals(result[2], 1, 0.0001);

	}

	@Test
	void fafhTest() {

		boolean doesIntersect = a.getIntersection(150, 100, 100, 100, 150, 100, 150, 200);

		double[] result = a.intersect();

		assertTrue(doesIntersect);

		assertEquals(result[0], 150, 0.0001);
		assertEquals(result[1], 100, 0.0001);
		assertEquals(result[2], 0, 0.0001);

	}

	@Test
	void fabcTest() {

		boolean doesIntersect = a.getIntersection(150, 100, 100, 100, 200, 100, 200, 200);

		double[] result = a.intersect();

		assertFalse(doesIntersect);

	}

	@Test
	public void exceptionTesting() {
		
		try {
			
			a.intersect();
		
		} catch(NullPointerException ne) {
			fail (ne.getMessage());
			
		}
		catch (IllegalArgumentException ie) {
			
			fail(ie.getMessage());
		}
		
		
		
	}

}
